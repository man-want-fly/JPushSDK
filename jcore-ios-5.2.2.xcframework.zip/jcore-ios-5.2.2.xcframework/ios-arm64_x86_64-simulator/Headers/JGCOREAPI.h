//
//  JGCOREService.h
//  JCore
//
//  Created by Shuni Huang on 2024/3/19.
//  Copyright © 2024 jiguang. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JGCOREAPI : NSObject

+ (void)ci:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
